# Twitter / X Video Downloader

Website berbahasa Indonesia untuk mengunduh video dari postingan X/Twitter publik. Frontend HTML/CSS/JS dan backend Express + yt-dlp.

## Online lewat Render (bisa diakses dari Chrome HP)
1. Ekstrak ZIP dan unggah isi folder `twitter-downloader` ke repository GitHub milik Anda.
2. Buka https://render.com lalu buat **New > Web Service** dan hubungkan repository tersebut.
3. Pilih **Docker** sebagai runtime (Render biasanya mendeteksi `Dockerfile` otomatis).
4. Klik **Deploy** dan tunggu build selesai. Render akan memberikan alamat `https://...onrender.com` yang bisa dibuka dari Chrome.

Alternatif: gunakan **New > Blueprint** dengan `render.yaml` dari repository.

Catatan: Hosting paket gratis mungkin sleep ketika tidak digunakan; beberapa platform membatasi durasi proses/penyimpanan, dan X dapat mengubah pembatasan akses video. Tidak semua video pasti bisa diunduh.

## Jalankan lokal
Memerlukan Node.js 18+, yt-dlp, dan ffmpeg terpasang di PATH.
```
npm install
npm start
```
Buka http://localhost:3000

Hanya unduh video publik yang Anda berhak gunakan. Video privat tidak didukung.
