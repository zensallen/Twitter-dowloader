import express from 'express';
import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const app = express();
app.use(express.static('public'));
const urlPattern = /^https?:\/\/(?:www\.|mobile\.)?(?:twitter\.com|x\.com)\/[^/?#]+\/status\/\d+(?:[/?#].*)?$/i;
app.get('/api/download', async (req, res) => {
  const url = String(req.query.url || '');
  if (!urlPattern.test(url)) return res.status(400).json({error:'Masukkan link postingan X/Twitter yang valid.'});
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'xdl-'));
  const output = path.join(dir, `${randomUUID()}.%(ext)s`);
  const child = spawn('yt-dlp', ['--no-playlist','--max-filesize','150M','--merge-output-format','mp4','-f','bv*+ba/b','-o',output,'--',url], {stdio:['ignore','ignore','pipe']});
  let error = '';
  const timeout = setTimeout(() => child.kill('SIGKILL'), 90000);
  child.stderr.on('data', chunk => { error = (error + chunk.toString()).slice(-2000); });
  const clean = () => fs.rm(dir, {recursive:true,force:true}).catch(()=>{});
  child.on('error', () => {clearTimeout(timeout);clean();if(!res.headersSent)res.status(500).json({error:'yt-dlp belum terpasang di server.'});});
  child.on('close', async code => {
    clearTimeout(timeout);
    if (res.headersSent) return clean();
    try {
      const files = await fs.readdir(dir);
      const file = files.find(f => /\.(mp4|webm|mkv)$/i.test(f));
      if(code !== 0 || !file) throw new Error('Video tidak dapat diunduh. Pastikan postingan publik dan berisi video.');
      res.download(path.join(dir,file), 'twitter-video'+path.extname(file), clean);
    } catch(e) { await clean(); res.status(422).json({error:e.message}); }
  });
});
app.listen(process.env.PORT || 3000, () => console.log('Buka http://localhost:3000'));
